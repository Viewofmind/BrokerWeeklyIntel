export type Trend = "Improving" | "Declining" | "Stable";
export type Severity = "critical" | "high" | "medium" | "low";
export type Sentiment = "positive" | "mixed" | "negative";
export type Platform = "x" | "reddit" | "web";

export interface NewFeature {
  broker?: string;
  feature_name: string;
  launch_date: string;
  user_reaction: "Positive" | "Mixed" | "Negative" | "Too early to tell";
  discussion_volume: "High" | "Medium" | "Low";
  evidence_links: string[];
}

export interface KeyQuote {
  quote: string;
  context: string;
  sentiment: "positive" | "negative" | "neutral";
  source_url: string;
  author?: string;
  platform: Platform;
  broker?: string;
}

export interface NegativeTheme {
  theme:
    | "Performance"
    | "Support"
    | "Charges"
    | "Reliability"
    | "UX"
    | "Features/Gaps"
    | "Transparency"
    | "Other";
  count: number;
  severity: Severity;
  example_quotes: string[];
}

export interface TechnicalIssue {
  broker?: string;
  description: string;
  severity: Severity;
  issue_type: "feature_specific" | "platform_wide";
  volume: number;
  first_seen: string;
  last_seen: string;
}

export interface BrokerReport {
  broker: string;
  slug: string;
  overall_rating: number;
  trend: Trend;
  previous_rating?: number;
  rating_breakdown: {
    engagement: number;
    sentiment: number;
    new_feature_response: number;
    technical_reliability: number;
    support: number;
    transparency: number;
    historical_trend: number;
  };
  new_features: NewFeature[];
  key_quotes: KeyQuote[];
  negative_themes: NegativeTheme[];
  technical_issues: TechnicalIssue[];
  watch_items: string[];
}

export interface WeeklyReport {
  week: string;
  week_start: string;
  week_end: string;
  report_version: "2.1";
  overall_sentiment: Sentiment;
  brokers: BrokerReport[];
  industry_themes: {
    positive: string[];
    negative: string[];
    emerging: string[];
    implications_for_investallign?: string;
  };
  new_features_summary: NewFeature[];
  watch_items_next_2_weeks: string[];
}

const BROKERS = [
  "Zerodha",
  "Groww",
  "Angel One",
  "Upstox",
  "Fyers",
  "ICICI Direct",
] as const;

const slugify = (s: string) => s.toLowerCase().replace(/\s+/g, "-");

function makeBroker(
  name: string,
  rating: number,
  prev: number,
  weekIdx: number,
): BrokerReport {
  const trend: Trend =
    rating - prev > 0.2 ? "Improving" : rating - prev < -0.2 ? "Declining" : "Stable";
  const seed = name.length + weekIdx;
  const rb = (n: number) => Math.max(3, Math.min(10, +(rating + ((seed * n) % 7) / 10 - 0.3).toFixed(1)));
  return {
    broker: name,
    slug: slugify(name),
    overall_rating: rating,
    previous_rating: prev,
    trend,
    rating_breakdown: {
      engagement: rb(1),
      sentiment: rb(2),
      new_feature_response: rb(3),
      technical_reliability: rb(4),
      support: rb(5),
      transparency: rb(6),
      historical_trend: rb(7),
    },
    new_features: [
      {
        broker: name,
        feature_name: `${name} Smart Orders v2`,
        launch_date: "2026-05-21",
        user_reaction: "Positive",
        discussion_volume: "High",
        evidence_links: ["https://x.com/example/1", "https://reddit.com/r/IndianStockMarket/x"],
      },
      {
        broker: name,
        feature_name: `${name} Mutual Fund SIP Pause`,
        launch_date: "2026-05-19",
        user_reaction: "Mixed",
        discussion_volume: "Medium",
        evidence_links: ["https://x.com/example/2"],
      },
    ],
    key_quotes: [
      {
        broker: name,
        quote: `${name}'s new order screen is finally fast on Android. Took them long enough.`,
        context: "Reaction to weekly app update",
        sentiment: "positive",
        source_url: "https://x.com/example/q1",
        author: "@trader_in",
        platform: "x",
      },
      {
        broker: name,
        quote: `Charts on ${name} froze again during opening bell. Lost a scalp.`,
        context: "Pre-market crash report",
        sentiment: "negative",
        source_url: "https://reddit.com/r/IndianStockMarket/q2",
        author: "u/optionspro",
        platform: "reddit",
      },
      {
        broker: name,
        quote: `Support replied in under an hour for KYC issue. Surprised.`,
        context: "Support ticket follow-up",
        sentiment: "positive",
        source_url: "https://x.com/example/q3",
        author: "@newinvestor",
        platform: "x",
      },
    ],
    negative_themes: [
      { theme: "Performance", count: 42, severity: "high", example_quotes: ["App lag during open"] },
      { theme: "Charges", count: 18, severity: "medium", example_quotes: ["Hidden DP charges"] },
      { theme: "Support", count: 27, severity: "high", example_quotes: ["No response for 3 days"] },
      { theme: "UX", count: 12, severity: "low", example_quotes: ["Confusing F&O flow"] },
    ],
    technical_issues: [
      {
        broker: name,
        description: "Order placement timeout at 9:15 AM",
        severity: "critical",
        issue_type: "platform_wide",
        volume: 156,
        first_seen: "2026-05-20",
        last_seen: "2026-05-23",
      },
      {
        broker: name,
        description: "Charts not loading on iOS 17",
        severity: "high",
        issue_type: "feature_specific",
        volume: 48,
        first_seen: "2026-05-21",
        last_seen: "2026-05-24",
      },
    ],
    watch_items: [
      "Monitor new Smart Orders rollout adoption",
      "Track support response SLA after recent outage",
    ],
  };
}

const weekDefs: Array<{
  week: string;
  week_start: string;
  week_end: string;
  ratings: Record<string, number>;
}> = [
  {
    week: "2026-W19",
    week_start: "2026-05-05",
    week_end: "2026-05-11",
    ratings: { Zerodha: 7.8, Groww: 7.2, "Angel One": 6.5, Upstox: 6.8, Fyers: 7.4, "ICICI Direct": 5.9 },
  },
  {
    week: "2026-W20",
    week_start: "2026-05-12",
    week_end: "2026-05-18",
    ratings: { Zerodha: 7.6, Groww: 7.4, "Angel One": 6.7, Upstox: 6.5, Fyers: 7.5, "ICICI Direct": 6.1 },
  },
  {
    week: "2026-W21",
    week_start: "2026-05-19",
    week_end: "2026-05-25",
    ratings: { Zerodha: 8.1, Groww: 7.6, "Angel One": 7.2, Upstox: 6.3, Fyers: 7.8, "ICICI Direct": 6.4 },
  },
];

export const WEEKLY_REPORTS: WeeklyReport[] = weekDefs.map((w, i) => {
  const prev = weekDefs[i - 1]?.ratings ?? w.ratings;
  return {
    week: w.week,
    week_start: w.week_start,
    week_end: w.week_end,
    report_version: "2.1",
    overall_sentiment: "mixed",
    brokers: BROKERS.map((b) => makeBroker(b, w.ratings[b], prev[b] ?? w.ratings[b], i)),
    industry_themes: {
      positive: [
        "Faster app performance after recent updates",
        "Better mutual fund discovery flows",
        "Improved support response times mid-week",
      ],
      negative: [
        "Recurring opening-bell outages",
        "Opaque charge structures around DP and AMC",
        "Slow KYC reactivation for dormant accounts",
      ],
      emerging: [
        "Demand for built-in options strategy builders",
        "Interest in API access at retail pricing",
        "Sentiment shift toward discount brokers from full-service",
      ],
      implications_for_investallign:
        "Lean into transparency on charges and publish a public uptime page. The market is rewarding brokers who own their incidents quickly.",
    },
    new_features_summary: BROKERS.flatMap((b) =>
      makeBroker(b, w.ratings[b], prev[b] ?? w.ratings[b], i).new_features,
    ),
    watch_items_next_2_weeks: [
      "Zerodha Kite update rollout to remaining users",
      "Groww F&O margin policy change reaction",
      "Angel One Super App v3 beta feedback",
      "Upstox response to charting complaints",
    ],
  };
});

export const getCurrentWeek = () => WEEKLY_REPORTS[WEEKLY_REPORTS.length - 1];
export const getWeek = (key: string) =>
  WEEKLY_REPORTS.find((w) => w.week === key) ?? getCurrentWeek();
